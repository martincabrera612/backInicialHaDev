const nunjucks = require("nunjucks");
const express = require("express");
const router = require("./routes");

const app = express();

nunjucks.configure(__dirname + "/views", {
  autoescape: true,
  express: app,
});

app.set("view engine", "njk");
router(app);

app.listen(3000, () => {
  console.log("Server up");
});

const { response } = require("express");

function homeHandler(req, res) {
  res.sendFile("index.html", { root: "./views" });
}

function productHandler(request, response) {
  const resultado = request.query.num1 * request.query.num2;
  response.render("result", { result: resultado });
}

function productsHandler(req, res) {
  const products = ["teclado", "mouse", "pc"];
  res.render("products", { products: products });
}

function registerRoutes(app) {
  app.get("/", homeHandler);

  app.get("/multiplicar", productHandler);

  app.get("/productos", productsHandler);
}

module.exports = registerRoutes;
